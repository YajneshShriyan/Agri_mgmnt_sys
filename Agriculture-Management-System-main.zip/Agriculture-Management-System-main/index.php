<?php
include("db.php");





?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Agriculture Information System Home Page</title>
    <meta name="description" content="Society-X Home Page" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">
    <link rel="stylesheet" href="./icss/bootstrap.min.css" />
    <link rel="stylesheet" href="./icss/animate.min.css" />
    <link rel="stylesheet" href="./icss/ionicons.min.css" />
    <link rel="stylesheet" href="./icss/styles.css" />
  </head>
  <body>
    <nav id="topNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#first"><i class="ion-ios-analytics-outline"></i>Agri-Info</a>
            </div>
            <div class="navbar-collapse collapse" id="bs-navbar">
                <ul class="nav navbar-nav">
                    
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li>
                       
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <header id="first">
        <div class="header-content">
            <div class="inner">
                <h3 style="color: pink;text-align: center;"></h5>
                <h1 class="cursive">Agriculture Information System</h1>

                <h4>Agriculture Information System Portal</h4>
                <hr>
                <a href="admin.php" id="toggleVideo"  class="btn btn-primary btn-xl">Admin Login</a> &nbsp; <a href="login.php" class="btn btn-primary btn-xl page-scroll">User Login</a> &nbsp; <a href="register.php" class="btn btn-primary btn-xl page-scroll">Register</a> 
            </div>
            </div>
        </div>
    
    </header>


  

   
    <!--scripts loaded here -->
    <script src="./ijs/jquery.min.js"></script>
    <script src="./ijs/bootstrap.min.js"></script>
    <script src="./ijs/jquery.easing.min.js"></script>
    <script src="./ijs/wow.js"></script>
    <script src="./ijs/scripts.js"></script>
  </body>
</html>